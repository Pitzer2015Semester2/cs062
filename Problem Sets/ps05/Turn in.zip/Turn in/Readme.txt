Run: $ java PageScanner practiceHtml.txt outFile.txt
Then open outFile.txt